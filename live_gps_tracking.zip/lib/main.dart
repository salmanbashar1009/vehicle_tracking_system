import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:live_gps_tracking/injection_container.dart';
import 'package:live_gps_tracking/presentation/app.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  await configureDependencies();
  runApp(const MyApp());
}
